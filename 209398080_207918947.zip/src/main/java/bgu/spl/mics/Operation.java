package bgu.spl.mics;

public class Operation {
    public int result;
    public boolean isDone;
    public Operation(){}
}
